# Create config.js file here and paste the contents of config.example.js into it.
# Then replace the API key with your own API key from Google AI Studio.
