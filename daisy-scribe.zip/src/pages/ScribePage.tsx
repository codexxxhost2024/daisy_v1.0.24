
import React, { useState, useRef, useEffect } from 'react';
import Header from '@/components/Header';
import BottomNavbar from '@/components/BottomNavbar';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, Mic, Pause, Play, Square, Save, Download, Mail } from 'lucide-react';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';
import { transcribeAudio } from '@/services/DeepgramService';
import { generateDocumentation } from '@/services/GeminiService'; // Import Gemini service
import { supabase } from '@/integrations/supabase/client';

// Example scribe content from SQL file
const exampleScribeContent = `**INTERNAL MEDICINE**

**Subjective:**
Patient: Maria Santos
Date: 03/27/2025
Time: 08:30 AM
Reason for Visit: Routine annual physical examination.
Patient reports being asymptomatic and is here for preventative wellness care.

**Objective:**
Vital signs: Not dictated.
Physical Exam: General adult medical examination performed. Findings are described as without abnormality.
Labs Ordered: Lipid panel, Glucose (quantitative, blood), Complete CBC with automated differential.

**Assessment:**
Z00.00 - Encounter for general adult medical examination without abnormal findings.
Patient requires routine preventative screening appropriate for age and risk profile.

**Plan:**
1.  Obtain labs as ordered: Lipid panel (80061), Glucose (84295), CBC w/ diff (85025).
2.  Follow up with patient regarding lab results.
3.  Provide counseling on age-appropriate preventative health measures.
4.  Schedule follow-up annual physical exam in one year.

**Insurance/Billing:**
Coding: ICD-10: Z00.00; CPT: 99396 (Preventive visit, established female, 40-64 years), 80061 (Lipid panel), 84295 (Glucose, quantitative, blood), 85025 (Complete CBC with automated differential).
Pre-auth: Not required for wellness exam or standard screening labs.
Notes: Bill CPT 99396 with Z00.00 as primary diagnosis. Labs bundled under wellness codes; submit for routine screening coverage. Medical Necessity: Annual physical as part of routine wellness care and preventative screening.`;

const ScribePage = () => {
  // State for recording and audio processing
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [currentAudioBlob, setCurrentAudioBlob] = useState<Blob | null>(null);
  const [transcription, setTranscription] = useState(''); // For display
  const [currentTranscription, setCurrentTranscription] = useState(''); // For saving
  const [aiResponse, setAiResponse] = useState('');
  const [fileName, setFileName] = useState('No file selected');
  const [showAiResponse, setShowAiResponse] = useState(false);
  const [wakeLock, setWakeLock] = useState<WakeLockSentinel | null>(null); // Use specific type
  const [recordingTime, setRecordingTime] = useState(0);
  const timerRef = useRef<number | null>(null);

  // Refs for audio elements
  const recordedAudioPlayerRef = useRef<HTMLAudioElement>(null);
  const uploadedAudioPlayerRef = useRef<HTMLAudioElement>(null);
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);

  // Format recording time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  // Handle timer for recording duration
  useEffect(() => {
    if (isRecording && !isPaused) {
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prevTime => prevTime + 1);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRecording, isPaused]);

  // Request wake lock to prevent screen sleep
  const requestWakeLock = async () => {
    if ('wakeLock' in navigator) {
      try {
        // Cast navigator to include wakeLock property
        const lock = await (navigator as Navigator & { wakeLock: WakeLock }).wakeLock.request('screen');
        setWakeLock(lock);
        lock.addEventListener('release', () => {
          console.log('Wake Lock released');
          setWakeLock(null);
         });
         console.log('Wake Lock acquired');
       } catch (err: unknown) {
         console.error(`Wake Lock error: ${err instanceof Error ? err.message : String(err)}`);
       }
     } else {
      console.warn('Wake Lock API not supported');
    }
  };

  // Release wake lock
  const releaseWakeLock = async () => {
    if (wakeLock) {
      try {
        await wakeLock.release();
        setWakeLock(null);
      } catch (err) {
        console.error(`Wake Lock release error: ${err}`);
      }
    }
  };

  // Start recording
  const startRecording = async () => {
    setTranscription('');
    setCurrentTranscription(''); // Clear saved transcription
    setAiResponse('');
    setShowAiResponse(false);
    setIsProcessing(true);
    setRecordingTime(0);

    if (!navigator.mediaDevices?.getUserMedia) {
      toast.error('Media API not supported in this browser');
      setIsProcessing(false);
      return;
    }

    try {
      toast.info('Requesting microphone access...');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;
      await requestWakeLock();

      setAudioChunks([]);
      setCurrentAudioBlob(null);

      // Find supported mime types
      let options = {};
      const supportedTypes = [
        'audio/webm;codecs=opus', 'audio/ogg;codecs=opus',
        'audio/webm', 'audio/ogg', 'audio/mp4', 'audio/aac'
      ];

      for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) {
          options = { mimeType: type };
          console.log(`Using mimeType: ${type}`);
          break;
        }
      }

      const recorder = new MediaRecorder(stream, options);
      
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          setAudioChunks(prev => [...prev, e.data]);
        }
      };

      recorder.onstop = () => {
        console.log('Recording stopped');
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());

        const chunks = audioChunks;
        if (chunks.length > 0) {
          const blobType = recorder.mimeType || 'audio/webm';
          const audioBlob = new Blob(chunks, { type: blobType });
          
          if (audioBlob.size > 0) {
            setCurrentAudioBlob(audioBlob);
            toast.success('Recording finished');
          } else {
            setCurrentAudioBlob(null);
            toast.warning('No audio data recorded');
          }
        }
        
        setIsRecording(false);
        setIsPaused(false);
        setIsProcessing(false);
        releaseWakeLock();
       };

       recorder.onerror = (e: Event) => {
         console.error('Recorder Error:', e);
         // Check if it's a MediaRecorderErrorEvent which has an 'error' property
         let errorName = 'Unknown error';
         if ('error' in e && e.error instanceof DOMException) {
           errorName = e.error.name;
         }
         toast.error(`Recording error: ${errorName}`);
         stream.getTracks().forEach(track => track.stop());
         setCurrentAudioBlob(null);
        setIsRecording(false);
        setIsPaused(false);
        setIsProcessing(false);
        releaseWakeLock();
      };

      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
      setIsPaused(false);
       toast.success('Recording started');

     } catch (err: unknown) {
       console.error('Mic/start error:', err);

       let errorMessage = 'Microphone access error';
       // Type check for specific error names
       if (err instanceof Error) {
         // Nest the name checks inside the instanceof check
         if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
           errorMessage = 'Microphone permission denied';
         } else if (err.name === 'NotFoundError') {
           errorMessage = 'No microphone found';
         } else if (err.name === 'NotReadableError') {
           errorMessage = 'Microphone is busy or has a hardware error';
         } else {
           // Default error message using the error's message property
           errorMessage = `Microphone access error: ${err.message}`;
         }
       } else {
         // Handle cases where err is not an Error instance
         errorMessage = `An unexpected error occurred: ${String(err)}`;
       }

      toast.error(errorMessage);
      setCurrentAudioBlob(null);
      setIsProcessing(false);
      releaseWakeLock();
    }
  };

  // Pause recording
  const pauseRecording = () => {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.pause();
      setIsPaused(true);
      toast.info('Recording paused');
      releaseWakeLock();
    }
  };

  // Resume recording
  const resumeRecording = async () => {
    if (mediaRecorder && mediaRecorder.state === 'paused') {
      await requestWakeLock();
      mediaRecorder.resume();
      setIsPaused(false);
      toast.info('Recording resumed');
    }
  };

  // Stop recording
  const stopRecording = () => {
    if (mediaRecorder && (mediaRecorder.state === 'recording' || mediaRecorder.state === 'paused')) {
      toast.info('Stopping recording...');
      mediaRecorder.stop();
    }
  };

  // Handle file upload
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (isProcessing) return;
    
    const file = event.target.files?.[0];
    
    setTranscription('');
    setCurrentTranscription(''); // Clear saved transcription
    setAiResponse('');
    setShowAiResponse(false);
    setCurrentAudioBlob(null);
    setAudioChunks([]);
    setIsProcessing(true);

    if (file) {
      if (!file.type || !file.type.startsWith('audio/')) {
        toast.error('Invalid file type. Please select an audio file.');
        event.target.value = '';
        setFileName('No file selected');
        setCurrentAudioBlob(null);
        setIsProcessing(false);
        return;
      }
      
      setCurrentAudioBlob(file);
      setFileName(file.name);
      toast.success('File uploaded successfully');
    } else {
      setFileName('No file selected');
    }
    
    setIsProcessing(false);
  };

  // Transcribe audio
  const handleTranscribe = async () => {
    if (!currentAudioBlob) {
      toast.error('No audio file selected or recorded to transcribe');
      return;
    }

    setIsProcessing(true);
    toast.info('Transcribing audio...');
    
    try {
      await requestWakeLock();
      
      // Use our Deepgram service
      const result = await transcribeAudio(currentAudioBlob);
      
       setTranscription(result.transcript); // Update display transcription
       setCurrentTranscription(result.transcript); // Update transcription to be saved
       toast.success('Transcription complete!');

     } catch (error: unknown) {
       const message = error instanceof Error ? error.message : String(error);
       console.error('Transcription Error:', error);
       toast.error(`Transcription failed: ${message}`);
       setTranscription(`Error during transcription.\n\n${message}`);
     } finally {
       setIsProcessing(false);
      releaseWakeLock();
    }
  };

  // Play recorded audio
  const playRecordedAudio = () => {
    if (currentAudioBlob && !(currentAudioBlob instanceof File) && recordedAudioPlayerRef.current) {
      const audioURL = URL.createObjectURL(currentAudioBlob);
      recordedAudioPlayerRef.current.src = audioURL;
      recordedAudioPlayerRef.current.play()
        .then(() => toast.info('Playing recorded audio...'))
        .catch(err => {
          toast.error(`Playback error: ${err.message}`);
          URL.revokeObjectURL(audioURL);
        });

      recordedAudioPlayerRef.current.onended = () => {
        URL.revokeObjectURL(audioURL);
      };
    } else {
      toast.warning('No recorded audio available for playback');
    }
  };

  // Play uploaded audio
  const playUploadedAudio = () => {
    if (currentAudioBlob instanceof File && uploadedAudioPlayerRef.current) {
      const audioURL = URL.createObjectURL(currentAudioBlob);
      uploadedAudioPlayerRef.current.src = audioURL;
      uploadedAudioPlayerRef.current.play()
        .then(() => toast.info('Playing uploaded audio...'))
        .catch(err => {
          toast.error(`Playback error: ${err.message}`);
          URL.revokeObjectURL(audioURL);
        });

      uploadedAudioPlayerRef.current.onended = () => {
        URL.revokeObjectURL(audioURL);
      };
    } else if (audioFileInputRef.current?.files?.[0]) {
      const file = audioFileInputRef.current.files[0];
      const audioURL = URL.createObjectURL(file);
      if (uploadedAudioPlayerRef.current) {
        uploadedAudioPlayerRef.current.src = audioURL;
        uploadedAudioPlayerRef.current.play()
          .then(() => toast.info('Playing uploaded audio...'))
          .catch(err => {
            toast.error(`Playback error: ${err.message}`);
            URL.revokeObjectURL(audioURL);
          });

        uploadedAudioPlayerRef.current.onended = () => {
          URL.revokeObjectURL(audioURL);
        };
      }
    } else {
      toast.warning('No uploaded file available for playback');
    }
  };

  // Generate AI response from transcription
  const generateAIResponse = async () => {
    if (!transcription.trim()) {
      toast.warning('No transcription text available to generate note');
      return;
    }

    setIsProcessing(true);
    toast.info('Generating AI scribe note...');
    setShowAiResponse(true);
    
    try {
      await requestWakeLock();

      // Call the actual Gemini service
      const generatedNote = await generateDocumentation(transcription);

      setAiResponse(generatedNote);
       toast.success('AI Scribe Note Generated!');

     } catch (error: unknown) {
       const message = error instanceof Error ? error.message : String(error);
       console.error('AI Generation Error:', error);
       toast.error(`AI generation failed: ${message}`);
       setAiResponse(`Error during AI note generation.\n\n${message}`);
     } finally {
       setIsProcessing(false);
       releaseWakeLock(); // Ensure wake lock is released even on error
    }
  };

  // Save scribe content to Supabase Storage as a TXT file
  const saveToStorage = async () => {
    if (!aiResponse.trim()) {
      toast.warning('No AI content to save');
      return;
    }

    setIsProcessing(true);
    toast.loading('Saving scribe to storage...');

    try {
      // Create a Blob from the AI response text
      const scribeBlob = new Blob([aiResponse], { type: 'text/plain' });

      // Generate a filename (e.g., scribe_YYYYMMDD_HHMMSS.txt)
      const timestamp = new Date().toISOString().replace(/[-:.]/g, '').replace('T', '_').slice(0, 15);
      const fileName = `scribe_${timestamp}.txt`;

      // Upload the file to the 'scribes' bucket
      const { data, error } = await supabase.storage
        .from('scribes') // Ensure this is your bucket name
        .upload(fileName, scribeBlob, {
          cacheControl: '3600',
          upsert: false, // Don't overwrite existing files with the same name (optional)
          contentType: 'text/plain',
        });

      if (error) throw error;

      console.log('Upload successful:', data);
      toast.dismiss(); // Dismiss loading toast
      toast.success('Scribe saved to storage successfully!');
    } catch (error: unknown) {
      toast.dismiss(); // Dismiss loading toast
      // Log the raw error for debugging
      console.error('Storage save error:', error);

      // Attempt to extract a meaningful message
      let errorMessage = 'An unknown error occurred during storage save.';
      if (error && typeof error === 'object') {
        // Check for Supabase/PostgrestError structure
        if ('message' in error && typeof error.message === 'string') {
          errorMessage = error.message;
        } else if ('details' in error && typeof error.details === 'string') { // Fallback for details
          errorMessage = error.details;
        } else if (error instanceof Error) { // Standard Error check
           errorMessage = error.message;
        } else {
           // If it's an object but not an Error and no message/details, stringify might be the best we can do
           // but avoid "[object Object]" if possible
           try {
             const str = JSON.stringify(error);
             if (str !== '{}') errorMessage = str;
           } catch (e) { /* ignore stringify error */ }
        }
      } else if (typeof error === 'string') { // If the thrown thing was just a string
        errorMessage = error;
      }

      toast.error(`Failed to save to storage: ${errorMessage}`); // Updated error message context
    } finally {
      setIsProcessing(false);
    }
  };

  // Save scribe content to Supabase Database table
  const saveToDatabase = async () => {
    if (!aiResponse.trim()) {
      // No need for a toast here as it's called internally by download
      console.warn('No AI content to save to database.');
      return; // Don't proceed if there's nothing to save
    }

    // No separate processing state needed as it's part of download flow
    // toast.loading('Saving scribe to database...'); // Avoid double loading toast

    try {
      const { error } = await supabase
        .from('scribes') // Target the 'scribes' table
        .insert([
          { content: aiResponse, transcription: currentTranscription }, // Insert AI response and transcription
        ]);

      if (error) throw error;

      // toast.dismiss(); // Avoid dismissing the download toast
      console.log('Scribe saved to database successfully!');
      // Optionally show a subtle success confirmation if needed, but might be noisy
      // toast.success('Saved to database');

    } catch (error: unknown) {
      // toast.dismiss(); // Avoid dismissing the download toast
      console.error('Database save error:', error);

      let errorMessage = 'An unknown error occurred during database save.';
      if (error && typeof error === 'object') {
        if ('message' in error && typeof error.message === 'string') {
          errorMessage = error.message;
        } else if ('details' in error && typeof error.details === 'string') {
          errorMessage = error.details;
        } else if (error instanceof Error) {
           errorMessage = error.message;
        } else {
           try {
             const str = JSON.stringify(error);
             if (str !== '{}') errorMessage = str;
           } catch (e) { /* ignore stringify error */ }
        }
      } else if (typeof error === 'string') {
        errorMessage = error;
      }

      // Show an error toast specifically for the database save failure
      toast.error(`Failed to save to database: ${errorMessage}`);
    } finally {
      // No processing state to reset here
    }
  };


  // Download AI content and save to DB
  const downloadAIContent = async () => { // Make async
    if (!aiResponse.trim()) {
      toast.warning('No AI content to download');
      return;
    }

    // --- Save to Database First ---
    await saveToDatabase(); // Call the database save function

    // --- Proceed with Local Download ---
    toast.info('Preparing download...'); // Give user feedback

    const blob = new Blob([aiResponse], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'scribe_note.txt';
    link.click();
    URL.revokeObjectURL(url);
    toast.success('File downloaded');
  };

  // Send email
  const sendEmail = () => {
    if (!aiResponse.trim()) {
      toast.warning('No AI content to email');
      return;
    }
    
    // Mock implementation
    toast.loading('Sending email...');
    
    setTimeout(() => {
      toast.success('Email sent successfully!');
    }, 1500);
  };

  // Load example scribe content
  const loadExampleScribe = () => {
    setAiResponse(exampleScribeContent);
    setShowAiResponse(true);
    toast.info('Example scribe loaded');
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (mediaRecorder) {
        if (mediaRecorder.state === 'recording' || mediaRecorder.state === 'paused') {
          mediaRecorder.stop();
        }
      }
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(track => track.stop());
      }
      releaseWakeLock();
    };
  }, [mediaRecorder]);

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <Header />
      
      <main className="container mx-auto pt-20 pb-28 px-4">
        {/* Removed redundant header text div */}

        <Card className="shadow-sm mb-6">
          <CardContent className="p-6 space-y-6">
            {/* Recording Controls */}
            <div className="flex flex-col items-center space-y-4">
              <div className="flex justify-center gap-4">
                {!isRecording ? (
                  <Button 
                    onClick={startRecording} 
                    className="w-14 h-14 rounded-full bg-black hover:bg-gray-800"
                    disabled={isProcessing}
                  >
                    <Mic size={24} className="text-white" />
                  </Button>
                ) : (
                  <>
                    {!isPaused ? (
                      <Button 
                        onClick={pauseRecording} 
                        className="w-14 h-14 rounded-full bg-black hover:bg-gray-800"
                        disabled={isProcessing}
                      >
                        <Pause size={24} className="text-white" />
                      </Button>
                    ) : (
                      <Button 
                        onClick={resumeRecording} 
                        className="w-14 h-14 rounded-full bg-black hover:bg-gray-800"
                        disabled={isProcessing}
                      >
                        <Play size={24} className="text-white" />
                      </Button>
                    )}
                    <Button 
                      onClick={stopRecording} 
                      className="w-14 h-14 rounded-full bg-black hover:bg-gray-800"
                      disabled={isProcessing}
                    >
                      <Square size={24} className="text-white" />
                    </Button>
                  </>
                )}
              </div>

              {isRecording && (
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${isPaused ? 'bg-yellow-500' : 'bg-red-500 animate-pulse'}`}></div>
                  <span className="text-sm font-medium text-gray-600 font-helvetica">{formatTime(recordingTime)}</span>
                </div>
              )}

              <Button
                onClick={playRecordedAudio}
                className="bg-black hover:bg-gray-800 text-white w-full max-w-xs"
                disabled={isProcessing || isRecording || !currentAudioBlob || (currentAudioBlob instanceof File)}
              >
                <Play size={18} className="mr-2" />
                Play Recorded
              </Button>

              <div className="w-full max-w-xs">
                <label 
                  htmlFor="audioFile" 
                  className={`flex items-center justify-center gap-2 w-full py-2 px-4 bg-black hover:bg-gray-800 text-white rounded-md cursor-pointer ${isProcessing ? 'opacity-50' : ''}`}
                >
                  <Upload size={18} />
                  Choose Audio File
                </label>
                <input
                  ref={audioFileInputRef}
                  type="file"
                  id="audioFile"
                  accept="audio/*"
                  className="hidden"
                  onChange={handleFileChange}
                  disabled={isProcessing}
                />
                <p className="text-xs text-gray-500 mt-1 text-center truncate">
                  {fileName}
                </p>
              </div>

              <div className="flex flex-col space-y-4 w-full max-w-xs">
                <Button
                  onClick={handleTranscribe}
                  className="bg-black hover:bg-gray-800 text-white"
                  disabled={isProcessing || isRecording || !currentAudioBlob}
                >
                  Transcribe File/Recording
                </Button>

                <Button
                  onClick={playUploadedAudio}
                  className="bg-black hover:bg-gray-800 text-white"
                  disabled={isProcessing || !(currentAudioBlob instanceof File) || isRecording}
                >
                  <Play size={18} className="mr-2" />
                  Play Uploaded
                </Button>
              </div>
            </div>

            {/* Status Indicator */}
            <div className="flex items-center justify-center min-h-[24px]">
              {isProcessing && (
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></div>
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-300"></div>
                </div>
              )}
            </div>

            {/* Transcription Output */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700 font-helvetica">Transcription:</label>
              <ScrollArea className="h-[200px] w-full border rounded-md bg-gray-50 p-3">
                <p className="whitespace-pre-wrap text-gray-800 font-helvetica text-sm">
                  {transcription || "Transcription will appear here..."}
                </p>
            </ScrollArea>
          </div>

          {/* Generate AI & Load Example Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 w-full">
            <Button
              onClick={generateAIResponse}
              className="bg-black hover:bg-gray-800 text-white flex-1" // Use flex-1 to allow buttons to grow
              disabled={isProcessing || isRecording || !transcription.trim()}
            >
              <Save size={18} className="mr-2" />
              Generate Scribe Note
            </Button>
            <Button
              onClick={loadExampleScribe}
              className="bg-gray-600 hover:bg-gray-700 text-white flex-1" // Use flex-1
              disabled={isProcessing || isRecording} // Disable if processing or recording
            >
              Load Example Scribe
            </Button>
          </div>

          {/* AI Response Output */}
          {showAiResponse && (
              <div className="space-y-3">
                <label className="text-sm font-semibold text-gray-700 font-helvetica">AI Generated Scribe Note:</label>
                {/* Render plain text response in a pre tag */}
                <ScrollArea className="h-[300px] w-full border rounded-md bg-gray-50 p-3">
                  <pre className="whitespace-pre-wrap text-gray-800 font-helvetica text-sm">
                    {aiResponse || "AI generated note will appear here..."}
                  </pre>
                </ScrollArea>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 justify-between">
                  <Button
                    onClick={saveToStorage} // Changed onClick handler
                    className="bg-black hover:bg-gray-800 text-white flex-grow"
                    disabled={!aiResponse.trim()}
                  >
                    Save Scribe {/* Kept button text */}
                  </Button>
                  <Button
                    onClick={downloadAIContent}
                    className="bg-black hover:bg-gray-800 text-white flex-grow"
                    disabled={!aiResponse.trim()}
                  >
                    <Download size={18} className="mr-2" />
                    Download
                  </Button>
                  <Button 
                    onClick={sendEmail} 
                    className="bg-black hover:bg-gray-800 text-white flex-grow"
                    disabled={!aiResponse.trim()}
                  >
                    <Mail size={18} className="mr-2" />
                    Send Email
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Add 35px spacing at the bottom */}
        <div className="h-[35px]"></div>
      </main>
      
      {/* Hidden audio players */}
      <audio ref={recordedAudioPlayerRef} className="hidden" />
      <audio ref={uploadedAudioPlayerRef} className="hidden" />

      <BottomNavbar />
    </div>
  );
};

export default ScribePage;
