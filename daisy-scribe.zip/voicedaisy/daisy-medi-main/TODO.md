# TODO List (if you want to contribute you can either do these or add your own)

- Polish code
- Lint code properly as indentaion and all of that is not consistent
- Add feature to enable/disable tools
- Ignore all TODO's as this is just a demo repo
